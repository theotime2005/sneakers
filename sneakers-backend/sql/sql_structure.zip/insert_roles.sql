USE `sneakers`;

INSERT INTO Roles (name) VALUES ("standard");
INSERT INTO Roles (name) VALUES ("admin");